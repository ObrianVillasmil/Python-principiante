from package.operacion.calcula import Calcula

calcula = Calcula()
