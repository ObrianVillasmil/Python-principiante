class CalculosAreas():
	
	def circulo():
		pass

	def cuadrado():
		pass

	def rectangulo():
		pass

		