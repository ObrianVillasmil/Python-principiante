from setuptools import setup

setup(
	name="PaqueteCalculos",
	version='1.0',
	description = 'Paquete con operaciones matematicas sencillas',
	author = 'Obrian Villasmil',
	packages =['calculos','calculos.package.operacion','calculos.package.basicos','calculos.package.area','calculos.package.raiz']
)