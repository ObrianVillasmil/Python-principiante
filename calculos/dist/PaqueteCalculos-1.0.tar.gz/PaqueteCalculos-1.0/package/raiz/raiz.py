class CalculosRaiz():
	
	def raizCuadrada():
		pass

	def raizCubica():
		pass