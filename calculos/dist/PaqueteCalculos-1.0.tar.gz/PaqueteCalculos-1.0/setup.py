from setuptools import setup

setup(
	name="PaqueteCalculos",
	version='1.0',
	description = 'Paquete con operaciones matematicas sencillas',
	author = 'Obrian Villasmil',
	scripts=[],
	packages =['package','package.operacion','package.basicos','package.area','package.raiz']
)