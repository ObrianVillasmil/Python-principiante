from setuptools import setup

setup(
	name="PaqueteArchivos",
	version='1.0',
	description = 'Paquete para creacion, lectura y modificacion de archivos',
	author = 'Obrian Villasmil',
	scripts=[],
	packages =['package','package.acciones']
)