from setuptools import setup

setup(
		name = "Validaciones",
		version = "1",
		description = "Validaciones, repaso de distribuibles",
		packages=['validaciones','validaciones']
	);